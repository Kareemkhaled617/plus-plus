class OrderRequestEntity {
  final bool isSuccess;
  final String message;

  OrderRequestEntity({required this.isSuccess, required this.message});
}
