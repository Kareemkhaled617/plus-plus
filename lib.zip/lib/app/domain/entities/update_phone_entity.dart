class UpdatePhoneEntity {
  final String message;

  UpdatePhoneEntity({required this.message});
}
