class PointRequestEntity {
  final int productId;

  const PointRequestEntity({required this.productId});
}
