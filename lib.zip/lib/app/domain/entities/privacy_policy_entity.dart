class PrivacyPolicyEntity {
  final String content;
  final String contentType;

  const PrivacyPolicyEntity({
    required this.content,
    required this.contentType,
  });
}
