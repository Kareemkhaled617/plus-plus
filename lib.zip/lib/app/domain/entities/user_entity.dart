class UserEntity {
  final int code;
  final String message;
  final bool newUser;

  UserEntity(
      {required this.code, required this.message, required this.newUser});
}
